.test <- function() BiocGenerics:::testPackage("annotate")
